<img width="1728" src="https://github.com/aggarwalsejal/Portfolio-React/assets/56756275/f3406530-f29e-4a38-9d79-2c0fa6a58a85">
<br /><br />
<p align=center> :heart: Show your love to this website <a href="https://aggarwalsejal.com/">aggarwalsejal.com</a> :heart:</p>

# :zap: Designed Using: <br>
 * CSS
 * HTML
 * JAVASCRIPT
 * REACT
